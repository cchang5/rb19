import FileInstances from './file';
import ArrayInstances from './array';

export default { FileInstances, ArrayInstances };
