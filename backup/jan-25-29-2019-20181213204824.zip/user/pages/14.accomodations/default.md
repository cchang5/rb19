---
title: Accomodations
---

## <font color="#FFFFFF">Accomodations</font>

<font color="#FFFFFF">
    More information will be posted.<br>
    In the interm, please contact Lady Bonifacio at <a href="mailto:lbonifacio@lbl.gov">lbonifacio@lbl.gov</a> for more information.<br><br>
    Due to a very busy conference schedule at San Francisco for January 2019, please try to book accomodations before the end of December. We have been told by local hotels that prices will go through the roof when the new year starts.
</font>