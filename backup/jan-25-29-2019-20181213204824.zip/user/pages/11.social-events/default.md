---
title: 'Social Events'
---

<h3><font color='#FFFFFF'>Banquet</font></h3>
<font color='#FFFFFF'>The banquet is scheduled for the evening of Sunday, January 27. Tentatively, the location will be at the <a href='https://www.berkeleycityclub.com/'>Berkeley City Club</a>. The menu for the night may be found <a href='https://www.berkeleycityclub.com/julias-restaurant.htm'>here</a>. The venue also offers <a href='https://www.berkeleycityclub.com/rooms--suites.htm'>hotel rooms</a>, and is at a very convenient location.
</font>
<table style="width:100%">
<tr>
    <th><img src='http://rb19.lbl.gov/user/pages/11.social-events/IMG_0360.jpg' width=400px></th>
        <th><img src='http://rb19.lbl.gov/user/pages/11.social-events/IMG_0362.jpg' width=400px></th>
    <th><img src='http://rb19.lbl.gov/user/pages/11.social-events/IMG_0363.jpg' width=400px></th>
    </tr>
    
</table>

