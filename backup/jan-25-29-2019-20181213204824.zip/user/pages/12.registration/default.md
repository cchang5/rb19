---
title: Registration
---

<h3> <font color="#FFFFFF">REGISTRATION </font></h3>

<font color="#FFFFFF">
    There is no registration fee for this workshop. RIKEN, Berkeley Lab, and the Department of Energy Office of Nuclear Physics is fully supporting this event. Registration is required for an accurate count of the number of participants in order to prepare for refreshments throughout the workshop. Registration also asks for dinner preferences for the workshop banquet on January 27.
</font>
<br><br>
<font color="#FFFFFF">Registration is handled through Lawrence Berkeley Lab </font>
<a href="https://conferences.lbl.gov/event/195/">Indico</a>.
<font color="#FFFFFF">
<br><br>
You will need to create an account on the Indico system for abstract submission. Please note that account creation takes approximately 1 business day.
<br><br>
Indico accounts may be created.<br>
Registration is now open.<br>
Registration deadline for arranged accomodations is Sunday December 9.<br>
Final registration deadline is Sunday January 13.
</font>