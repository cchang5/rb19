---
title: Dates
---

## <font color="#FFFFFF">Important Dates</font>
<font color="#FFFFFF">
Sunday December 9 - Registration deadline with arranged accomodations.<br>
Sunday January 13 - Registration deadline.<br>
Monday January 14 - Abstract submission deadline.
</font>