---
title: Mission
menu: 'Easy Content'
image_align: right
---

<font color=#FFFFFF>
    RIKEN, Berkeley Lab and the University of California, Berkeley are co-hosting a workshop on Quantum Information Science.<br><br>
    Initiated by the RIKEN Interdisciplinary Theoretical and Mathematical Sciences (iTHEMS) program at Berkeley, this workshop will focus on the development of quantum computing techniques, quantum materials, and quantum sensing, as well as their corresponding applications to physical sciences, with an emphasis to galvanize the participants into future collaboration.<br><br>
    Welcome to the Golden State.
</font>
