---
title: Participants
---

<h3><font color='#FFFFFF'>Participants</font></h3>

<font color='#FFFFFF'>
<table style="width:100%">
<tr>
<th>Name</th>
<th>Institution</th>
<th>Country/Region</th>
</tr>
<tr>
<td>CARTER, Jonathan </td>
<td>Lawrence Berkeley National Lab </td>
<td>United States</td>
</tr>
<tr>
<td>CHANG, Chia Cheng </td>
<td>RIKEN iTHEMS / LBNL </td>
<td>United States</td>
</tr>
<tr>
<td>DE JONG, Wibe </td>
<td>LBNL </td>
<td>United States</td>
</tr>
<tr>
<td>DOI, Takumi </td>
<td>RIKEN </td>
<td>Japan</td>
</tr>
<tr>
<td>FUKUHARA, Takeshi </td>
<td>RIKEN CEMS </td>
<td>Japan</td>
</tr>
<tr>
<td>HATSUDA, Tetsuo </td>
<td>RIKEN </td>
<td>Japan</td>
</tr>
<tr>
<td>HAXTON, Wick </td>
<td>UC Berkeley and LBNL </td>
<td>United States</td>
</tr>
<tr>
<td>KAWATSU, Yuko </td>
<td>Riken iTHEMS </td>
<td>Japan</td>
</tr>
<tr>
<td>MARKOV, Igor </td>
<td>University of Michigan </td>
<td>United States</td>
</tr>
<tr>
<td>MATSUURA, Shunji </td>
<td>1QBit </td>
<td>Canada</td>
</tr>
<tr>
<td>MCELVAIN, Kenneth </td>
<td>UC Berkeley </td>
<td>United States</td>
</tr>
<tr>
<td>NISHIMORI, Hidetoshi </td>
<td>Tokyo Institute of Technology </td>
<td>Japan</td>
</tr>
<tr>
<td>ONO, Keiji </td>
<td>RIKEN </td>
<td>Japan</td>
</tr>
<tr>
<td>OTA, Chikako </td>
<td>RIKEN iTHEMS </td>
<td>Japan</td>
</tr>
<tr>
<td>OTSUKA, Yuichi </td>
<td>RIKEN </td>
<td>Japan</td>
</tr>
<tr>
<td>OZAWA, Tomoki </td>
<td>RIKEN iTHEMS </td>
<td>Japan</td>
</tr>
<tr>
<td>PARKER, Richard </td>
<td>University of California, Berkeley </td>
<td>United States</td>
</tr>
<tr>
<td>SOTA, Shigetoshi </td>
<td>RIKEN Center for Computational Science </td>
<td>Japan</td>
</tr>
<tr>
<td>SYMONS, Timothy James </td>
<td>Lawrence Berkeley National Laboratory </td>
<td>United States</td>
</tr>
<tr>
<td>TAKADA, KABUKI </td>
<td>Tokyo Institute of Technology </td>
<td>Japan</td>
</tr>
<tr>
<td>TAKI, Masato </td>
<td>RIKEN </td>
<td>Japan</td>
</tr>
<tr>
<td>TARUCHA, Seigo </td>
<td>Center for Emergent Matter Science, RIKEN </td>
<td>Japan</td>
</tr>
<tr>
<td>TSUBOI, Takashi </td>
<td>RIKEN iTHEMS </td>
<td>Japan</td>
</tr>
<tr>
<td>WALKER-LOUD, Andre </td>
<td>Lawrence Berkeley National Laboratory </td>
<td>United States</td>
</tr>
<tr>
<td>YU, Dong </td>
<td>U.C. Davis </td>
<td>United States</td>
</tr>
<tr>
<td>YUNOKI, Seiji </td>
<td>RIKEN </td>
<td>Japan</td>
</tr>
</table>
</font>