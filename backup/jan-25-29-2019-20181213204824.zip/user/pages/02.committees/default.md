---
title: Committees
content:
    items: '@self.modular'
    order:
        by: ''
        dir: ''
---

<h3> <font color="#FFFFFF">COMMITTEES </font></h3>
<div class="row">
  <div class="column">
      <h4> <font color="#FFFFFF">ORGANIZING COMMITTEE</font></h4>
      <font color="#FFFFFF">
      Chia Cheng Chang (RIKEN iTHEMS/UCB/LBNL NSD)</br>
      Takumi Doi (RIKEN iTHEMS)</br>
      Tetsuo Hatsuda (RIKEN iTHEMS)</br>
      Wick Haxton (UCB/LBNL NSD/RIKEN iTHEMS)</br>
      Alan Poon (LBNL NSD/BQ)
      </font>
  </div>
  <div class="column">
      <h4> <font color="#FFFFFF">ADVISORY COMMITTEE</font></h4>
    <font color="#FFFFFF">
       Jonathan Carter (LBNL CRD/BQ)</br>
       Yasunobu Nakamura (RIKEN CEMS/Tokyo)</br>
       Franco Nori (RIKEN/Michigan)</br>
       Thomas Schenkel (LBNL AT-AP/BQ)</br>
       Irfan Siddiqi (UCB/BQ)</br>
       Seigo Tarucha (RIKEN CEMS/Tokyo)
      </font>
  </div>
</div> 