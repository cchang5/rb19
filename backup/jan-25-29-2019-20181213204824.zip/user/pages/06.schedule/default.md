---
title: Schedule
---

 <h2><font color="#FFFFFF">Schedule</font></h2>
 <font color="#FFFFFF">A detailed schedule may be found at the <a href="https://conferences.lbl.gov/event/195/timetable/#20190125"> Indico</a> website for this workshop.
    </font>