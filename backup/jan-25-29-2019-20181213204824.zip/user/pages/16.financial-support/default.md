---
title: 'Financial Support'
---

<h3><font color='#FFFFFF'>Financial Support</font></h3>

<font color='#FFFFFF'>
There is funding for travel to supplement students.<br>
For more information, please contact Alan Poon at <a href='mailto:awpoon@lbl.gov'>awpoon@lbl.gov</a>.<br><br>
For non-RIKEN affiliates, there may also be limited workshop funding for travel.<br>
    Please contact Tetsuo Hatsuda at <a href='mailto:thatsuda@riken.jp'>thatsuda@riken.jp</a> for more information.
    </font>
    