---
title: Posters
media_order: plain_web.png
---

<h3><font color='#FFFFFF'>Posters</font></h3>

<table style="width:100%">
    <tr>
    <th><font color='#FFFFFF'>Continuum</font></th>
    <th><font color='#FFFFFF'>Hexagonal lattice</font></th> 
    <th><font color='#FFFFFF'>Kagome lattice</font></th>
  </tr>

    <tr>
	<th><a href="http://rb19.lbl.gov/user/pages/17.posters/RB19_plain-01.png" download><img src="http://rb19.lbl.gov/user/pages/17.posters/plain_web.png" alt="plain" width=300px></a></th>
    <th><a href="http://rb19.lbl.gov/user/pages/17.posters/RB19_hex-01.png" download><img src="http://rb19.lbl.gov/user/pages/17.posters/hex_web.png" alt="plain" width=300px></a></th>
	<th><a href="http://rb19.lbl.gov/user/pages/17.posters/RB19_kagome-01.png" download><img src="http://rb19.lbl.gov/user/pages/17.posters/kagome_web.png" alt="plain" width=300px></a></th>
    </tr>
    </table>
